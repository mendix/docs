/// <reference path="jsonpath/jsonpath.d.ts" />
/// <reference path="lodash/lodash.d.ts" />
/// <reference path="node/node.d.ts" />
/// <reference path="rest/rest.d.ts" />
/// <reference path="when/when.d.ts" />
/// <reference path="xml2js/xml2js.d.ts" />
