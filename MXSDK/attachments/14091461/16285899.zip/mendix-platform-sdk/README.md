Make sure to have `../mendixmodelsdk-0.0.1.tgz` available.

Then run `build.bat`.
