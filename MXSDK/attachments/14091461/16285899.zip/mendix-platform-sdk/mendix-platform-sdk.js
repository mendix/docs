var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/// <reference path="./typings/tsd.d.ts" />
var mendixmodelsdk_1 = require("mendixmodelsdk");
var fs = require("fs");
var path = require("path");
var when = require("when");
var _ = require("lodash");
var rest = require("rest");
var interceptor = require("rest/interceptor");
var pathPrefix = require("rest/interceptor/pathPrefix");
var xml2js = require("xml2js");
var jsonpath = require("jsonpath");
/**
 * The state of the background job:
 *
 * - Running: the job has been submitted for execution
 * - Completed: the job has been successfully completed
 * - Failed: the job has finished with an error
 */
(function (JobState) {
    JobState[JobState["Running"] = 0] = "Running";
    JobState[JobState["Completed"] = 1] = "Completed";
    JobState[JobState["Failed"] = 2] = "Failed";
})(exports.JobState || (exports.JobState = {}));
var JobState = exports.JobState;
var EmptyError = (function (_super) {
    __extends(EmptyError, _super);
    function EmptyError(message) {
        _super.call(this, message);
        this.message = message;
    }
    return EmptyError;
})(Error);
var ParseError = (function (_super) {
    __extends(ParseError, _super);
    function ParseError(message) {
        _super.call(this, message);
        this.message = message;
    }
    return ParseError;
})(Error);
/**
 * Client class that provides access to all Platform and Model APIs.
 */
var MendixSdkClient = (function () {
    /**
         * Create a new client to access [Mendix](developer.mendix.com) Platform and Model APIs.
         *
         * @param username Username of your account (same as username used to log in to the Mendix Development Portal)
         * @param apikey API key for your account.
         */
    function MendixSdkClient(username, apikey, password, openid, projectsApiEndpoint, modelApiEndpoint) {
        var credentials;
        if (apikey) {
            credentials = {
                username: username,
                apikey: apikey
            };
        }
        else if (password && openid) {
            credentials = {
                username: username,
                password: password,
                openid: openid
            };
        }
        else {
            throw new Error("Incomplete credentials");
        }
        this._modelSdkClient = new mendixmodelsdk_1.ModelSdkClient({
            credentials: credentials,
            endPoint: modelApiEndpoint ? modelApiEndpoint : MendixSdkClient.DEFAULT_MODELAPI_ENDPOINT
        });
        this._platformSdkClient = new PlatformSdkClient(this, username, apikey, projectsApiEndpoint ? projectsApiEndpoint : MendixSdkClient.DEFAULT_PROJECTSAPI_ENDPOINT);
    }
    MendixSdkClient.prototype.platform = function () {
        return this._platformSdkClient;
    };
    MendixSdkClient.prototype.model = function () {
        return this._modelSdkClient;
    };
    /**
    * Retrieve all your Mendix App projects.
    *
    * @returns An array of Project instances that each represent one of your Mendix Platform projects.
    */
    MendixSdkClient.prototype.retrieveProjects = function () {
        return this._platformSdkClient.retrieveProjects(this);
    };
    MendixSdkClient.DEFAULT_MODELAPI_ENDPOINT = "https://model-api.cfapps.io";
    MendixSdkClient.DEFAULT_PROJECTSAPI_ENDPOINT = "https://sprintr.home.mendix.com";
    return MendixSdkClient;
})();
exports.MendixSdkClient = MendixSdkClient;
// Internal (similar to the Model API 'SdkClient')
var PlatformSdkClient = (function () {
    function PlatformSdkClient(client, username, apikey, projectsApiEndpoint) {
        this._client = client;
        this._username = username;
        this._apikey = apikey;
        this._xmlParser = new xml2js.Parser();
        this._projectsApiEndpoint = projectsApiEndpoint;
    }
    /**
    * Creates a new app and commits it to the Team Server.
    *
    * @param projectName The name of the new app
    * @param projectSummary (Optional) A short description of the new app
    * @returns a Promise of a Mendix App Project
    */
    PlatformSdkClient.prototype.createNewApp = function (projectName, projectSummary) {
        var _this = this;
        console.log("Creating new project with name " + projectName + " for user " + this._username + "...");
        var contents = this._createRequestContent(PlatformSdkClient.CreateNewAppXml, {
            "ProjectName": projectName,
            "ProjectSummary": projectSummary,
            "User": this._username,
            "ApiKey": this._apikey
        });
        var apiClient = rest
            .wrap(this._createHttpErrorCodeInterceptor("Failed to create new app"))
            .wrap(this._parseResult())
            .wrap(pathPrefix, { prefix: this._projectsApiEndpoint });
        return apiClient(contents)
            .then(function (response) {
            var jobId = response.entity;
            console.log("Project creation for user " + _this._username + " underway with job id: " + jobId + "...");
            return _this._awaitJobResult(jobId);
        })
            .then(function (jobResult) {
            console.log("Project created successfully for user " + _this._username + " with id " + jobResult.result);
            return new Project(_this._client, jobResult.result, projectName);
        });
    };
    /**
    * TODO: implementation
    */
    PlatformSdkClient.prototype.retrieveProjects = function (client) {
        var _this = this;
        console.log("Retrieving projects for user " + this._username + "...");
        // TODO: Implement this properly, including templating of the entity
        var apiClient = rest.wrap(pathPrefix, { prefix: this._projectsApiEndpoint });
        return apiClient({
            path: PlatformSdkClient.PROJECTS_API_PATH,
            method: "POST",
            entity: null // TODO: templating
        }).then(function (response) {
            // TODO: Extract raw list of projects from response entity.
            var rawProjects = response.entity;
            // TODO: Return a mapping of each raw project to a nicely typed representation.
            var projects = rawProjects.map(function (raw) { return new Project(client, 'TODO-ID', 'Sprintr'); });
            console.log('Retrieved projects for user %s: %s', _this._username, projects.map(function (p) { return p.id() + ':' + p.name(); }).join(', '));
            return projects;
        });
    };
    /**
    * TODO: implementation
    */
    PlatformSdkClient.prototype.retrieveBranches = function (project) {
        console.log('Retrieving branches for project %s : %s', project.id(), project.name());
        return when.promise(function (resolve, reject) {
            // TODO: Retrieve available branches from the Platform API
            var branches = [];
            console.log('Successfully retrieved branches for project %s : %s : %s', project.id(), project.name(), branches.map(function (b) { return b.name; }).join(', '));
            resolve(branches);
        });
    };
    /**
    * Expose a specific Team Server revision as an Online Working Copy.
    *
    * @param project an instance of a Mendix App Project
    * @param revision A Revision instance pointing to a revision number on a specific Team Server branch
    * @returns a Promise of an OnlineWorkingCopy in the Mendix Model Server corresponding to the given project and revision.
    */
    PlatformSdkClient.prototype.createOnlineWorkingCopy = function (project, revision) {
        var _this = this;
        console.log("Creating new online working copy for project " + project.id() + " : " + project.name());
        var request = this._createRequestContent(PlatformSdkClient.CreateOnlineWorkingCopyXml, {
            "Username": this._username,
            "ApiKey": this._apikey,
            "ProjectId": project.id(),
            "Branch": revision ? revision.branch().name() : null,
            "Revision": revision ? revision.num() : null
        });
        var apiClient = rest
            .wrap(this._createHttpErrorCodeInterceptor("Failed to create online working copy"))
            .wrap(this._parseResult())
            .wrap(pathPrefix, { prefix: this._projectsApiEndpoint });
        return apiClient(request)
            .then(function (response) {
            var jobId = response.entity;
            return _this._awaitJobResult(jobId);
        })
            .then(function (jobResult) {
            var wcId = jobResult.result;
            console.log('Successfully created new online working copy %s for project %s : %s', wcId, project.id(), project.name());
            return when.promise(function (resolve, reject) {
                _this._client.model().openWorkingCopy(wcId, function (model) {
                    console.log("Successfully opened new online working copy " + wcId + " for project " + project.id() + " : " + project.name());
                    var rev = revision ? revision : new Revision(-1, new Branch(project, null));
                    var workingCopy = new OnlineWorkingCopy(_this._client, wcId, rev, model);
                    resolve(workingCopy);
                }, function (error) {
                    console.error('Failed to open new online working copy %s for project %s : %s:', wcId, project.id(), project.name());
                    reject(error);
                });
            });
        });
    };
    /**
    * Commit changes in your Online Working Copy to your model back to the Team Server.
    *
    * @param workingCopy an OnlineWorkingCopy instance pointing to a working copy on the Mendix Model server.
    * @param branchName (Optional) The name of the branch to commit to, or null for main line. Default is null.
    * @param baseRevision (Optional) The base revision for this commit, or -1 for HEAD. Default is -1.
    * @returns a Promise of a Team Server Revision corresponding to the given workingCopy.
    */
    PlatformSdkClient.prototype.commitToTeamServer = function (workingCopy, branchName, baseRevision) {
        var _this = this;
        if (branchName === void 0) { branchName = null; }
        if (baseRevision === void 0) { baseRevision = -1; }
        if (workingCopy == null || workingCopy.project() == null) {
            return when.reject("Working copy is empty or does not contain referral to project");
        }
        else if (baseRevision < -1) {
            return when.reject("Invalid base revision " + baseRevision);
        }
        console.log("Committing changes in online working copy " + workingCopy.id() + " to team server project " + workingCopy.project().id() + " branch " + branchName + " base revision " + baseRevision);
        var request = this._createRequestContent(PlatformSdkClient.CommitWorkingCopyChangesXml, {
            "Username": this._username,
            "ApiKey": this._apikey,
            "WorkingCopyId": workingCopy.id(),
            "ProjectId": workingCopy.project().id(),
            "Branch": branchName,
            "Revision": baseRevision
        });
        var apiClient = rest
            .wrap(this._createHttpErrorCodeInterceptor("Failed to commit to team server"))
            .wrap(this._parseResult())
            .wrap(pathPrefix, { prefix: this._projectsApiEndpoint });
        return apiClient(request)
            .then(function (response) {
            var jobId = response.entity;
            return _this._awaitJobResult(jobId);
        })
            .then(function (jobResult) {
            return when.promise(function (resolve, reject) {
                var num = parseInt(jobResult.result);
                if (num == null) {
                    reject("Failed to commit changes to team server: revision " + num + " on branch " + branchName + ". Reason: returned job id is not a number.");
                }
                else {
                    console.log("Successfully committed changes to team server: revision " + num + " on branch " + branchName);
                    var branch = new Branch(workingCopy.project(), branchName);
                    var revision = new Revision(num, branch);
                    resolve(revision);
                }
            });
        });
    };
    PlatformSdkClient.prototype._awaitJobResult = function (jobId) {
        var _this = this;
        return when.promise(function (resolve, reject) {
            setTimeout(function () {
                var request = _this._createRequestContent(PlatformSdkClient.RetrieveJobStatusXml, { "JobId": jobId });
                var client = rest
                    .wrap(_this._createHttpErrorCodeInterceptor('Error when retrieving job status'))
                    .wrap(_this._parseJobStatus())
                    .wrap(pathPrefix, { prefix: _this._projectsApiEndpoint });
                client(request).done(function (response) {
                    var state = response.entity.state;
                    if (JobState[state] === JobState.Completed) {
                        resolve(response.entity);
                    }
                    else if (JobState[state] === JobState.Failed) {
                        reject(response.entity.errorMessage);
                    }
                    else {
                        _this._awaitJobResult(jobId).done(resolve, reject);
                    }
                }, reject);
            }, 1000);
        });
    };
    PlatformSdkClient.prototype._createRequestContent = function (template, data) {
        var payload = this._compilePayload(template, data);
        return {
            path: PlatformSdkClient.PROJECTS_API_PATH,
            method: 'POST',
            headers: {
                'Content-Type': 'text/xml;charset=UTF-8'
            },
            mixin: {
                rejectUnauthorized: false
            },
            entity: payload
        };
    };
    PlatformSdkClient.prototype._compilePayload = function (template, data) {
        var xmlPayloadTemplate = fs.readFileSync(template, 'utf8');
        var compileXmlPayload = _.template(xmlPayloadTemplate);
        var payload = compileXmlPayload(data);
        return payload;
    };
    PlatformSdkClient.prototype._parseResult = function () {
        var _this = this;
        return interceptor({
            success: function (response, config, meta) {
                if (_.isEmpty(response.entity)) {
                    return when.reject('Error: HTTP response entity missing');
                }
                else {
                    return _this._parseAndQuery(response.entity, '$..Result[0]')
                        .then(function (result) {
                        response.entity = result;
                        return response;
                    });
                }
            }
        });
    };
    PlatformSdkClient.prototype._parseJobStatus = function () {
        var _this = this;
        return interceptor({
            success: function (response, config, meta) {
                if (_.isEmpty(response.entity)) {
                    return when.reject("Error: HTTP response entity missing");
                }
                else {
                    return when.promise(function (resolve, reject) {
                        xml2js.parseString(response.entity, function (error, parsed) {
                            if (error) {
                                console.error("Something went wrong: " + error);
                                reject(error);
                            }
                            else {
                                response.entity = _this._parseJobResult(parsed);
                                resolve(response);
                            }
                        });
                    });
                }
            }
        });
    };
    PlatformSdkClient.prototype._parseJobResult = function (parsed) {
        var jobId = jsonpath.query(parsed, '$..JobId[0]')[0];
        var startTime = jsonpath.query(parsed, '$..StartTime[0]')[0];
        var endTime = jsonpath.query(parsed, '$..EndTime[0]')[0];
        var state = jsonpath.query(parsed, '$..State[0]')[0];
        var result = jsonpath.query(parsed, '$..Result[0]')[0];
        var errorMessage = jsonpath.query(parsed, '$..ErrorMessage[0]')[0];
        return {
            jobId: jobId,
            startTime: startTime,
            endTime: endTime,
            state: state,
            result: result,
            errorMessage: errorMessage
        };
    };
    PlatformSdkClient.prototype._parseAndQuery = function (xml, query) {
        var _this = this;
        this._xmlParser.reset();
        var valPromise = when.promise(function (resolve, reject) {
            _this._xmlParser.parseString(xml, function (err, result) {
                if (err) {
                    var error = new ParseError(err);
                    reject(error);
                }
                else {
                    var parseResult = jsonpath.query(result, query)[0];
                    if (_.isEmpty(parseResult)) {
                        var error = new EmptyError("Query " + query + " on " + parseResult + " does not give any result");
                        reject(error);
                    }
                    else {
                        resolve(parseResult);
                    }
                }
            });
        });
        return valPromise;
    };
    PlatformSdkClient.prototype._createHttpErrorCodeInterceptor = function (errorMessage) {
        var _this = this;
        var response = function (response) {
            return when.promise(function (resolve, reject) {
                if (response.error) {
                    reject("Connection error: " + response.error);
                }
                else if (_.isEmpty(response.status) || _.isEmpty(response.entity)) {
                    reject("Error: invalid HTTP response");
                }
                else if (response.status.code === PlatformSdkClient.HTTP_STATUS_OK_RESPONSE_CODE) {
                    resolve(response);
                }
                else if (response.status.code === PlatformSdkClient.HTTP_STATUS_WS_ERROR_RESPONSE_CODE) {
                    _this._parseAndQuery(response.entity, '$..faultstring[0]')
                        .done(function (cause) {
                        reject(errorMessage + ": " + cause);
                    }, function (error) {
                        reject(error);
                    });
                }
                else {
                    reject("Unexpected HTTP response code: " + response.status.code + " " + response.raw.response.statusMessage + ". Please retry after a few minutes. If the problem persists, please consult https://mxforum.mendix.com");
                }
            });
        };
        return interceptor({
            response: response
        });
    };
    PlatformSdkClient._templatePath = function (filename) {
        return path.join(__dirname, 'templates', filename);
    };
    PlatformSdkClient.PROJECTS_API_PATH = "/ws/ProjectsAPI/9/soap1";
    PlatformSdkClient.HTTP_STATUS_OK_RESPONSE_CODE = 200;
    PlatformSdkClient.HTTP_STATUS_WS_ERROR_RESPONSE_CODE = 500;
    PlatformSdkClient.CreateNewAppXml = PlatformSdkClient._templatePath("CreateNewApp.xml");
    PlatformSdkClient.CreateOnlineWorkingCopyXml = PlatformSdkClient._templatePath("CreateOnlineWorkingCopy.xml");
    PlatformSdkClient.CommitWorkingCopyChangesXml = PlatformSdkClient._templatePath("CommitWorkingCopyChanges.xml");
    PlatformSdkClient.RetrieveJobStatusXml = PlatformSdkClient._templatePath("RetrieveJobStatus.xml");
    return PlatformSdkClient;
})();
exports.PlatformSdkClient = PlatformSdkClient;
/**
 * Representation of a Mendix App Project
 */
var Project = (function () {
    /**
    * @param client a MendixSdkClient instance
    * @param id Project id returned by the Mendix Projects API
    * @param name The desired project name
    */
    function Project(client, id, name) {
        this._client = client;
        this._id = id;
        this._name = name;
    }
    /**
         * @returns ID of this Project
         */
    Project.prototype.id = function () {
        return this._id;
    };
    /**
         * @returns name of this Project
         */
    Project.prototype.name = function () {
        return this._name;
    };
    Project.prototype.retrieveBranches = function () {
        return this._client.platform().retrieveBranches(this);
    };
    /**
         * Create a new Online Working Copy for the given project based on a given revision.
         *
         * @param revision The team server revision number.
         * @returns A Promise of a WorkingCopy instance that represents your new Online Working Copy.
         */
    Project.prototype.createWorkingCopy = function (revision) {
        return this._client.platform().createOnlineWorkingCopy(this, revision);
    };
    ;
    Project.prototype.createFeedbackItem = function (name, description, onSuccess, onError) {
        // TODO
    };
    Project.prototype.createUserStory = function (name, description, onSuccess, onError) {
        // TODO
    };
    return Project;
})();
exports.Project = Project;
/**
 * An Online Working Copy, which contains a snapshot of your Mendix App model.
 */
var OnlineWorkingCopy = (function () {
    function OnlineWorkingCopy(client, id, sourceRevision, store) {
        this._client = client;
        this._id = id;
        this._sourceRevision = sourceRevision;
        this._model = store;
    }
    /**
         * @returns ID of this Online Working Copy
         */
    OnlineWorkingCopy.prototype.id = function () {
        return this._id;
    };
    /**
    * @returns Revision (which contains the team server source branch) of this Online Working Copy
    */
    OnlineWorkingCopy.prototype.sourceRevision = function () {
        return this._sourceRevision;
    };
    /**
         * @returns The project of which this Online Working Copy contains a model snapshot.
         */
    OnlineWorkingCopy.prototype.project = function () {
        return this._sourceRevision.branch().project();
    };
    /**
         * @returns The model stored in this Online Working Copy
         */
    OnlineWorkingCopy.prototype.model = function () {
        return this._model;
    };
    /**
         * Commit changes in this Online Working Copy to the Team Server.
         * IMPORTANT: After committing, the connection to the Model Server is closed.
         * This means that you cannot commit any changes you make to the working copy after first committing.
         * If you want to make any further changes, create a new working copy by calling createWorkingCopy()
         * on the returned revision.
         *
         * @param branchName (Optional) the branch to commit to. Use null for main line.
         * @param baseRevision (Optional) the base revision of this commit.
         * @returns a Promise of a Team Server Revision
         */
    OnlineWorkingCopy.prototype.commit = function (branchName, baseRevision) {
        var _this = this;
        return when.promise(function (resolve, reject) {
            console.log("Closing connection to Model API...");
            _this._model.closeConnection(function () {
                console.log("Closed connection to Model API successfully.");
                resolve(null);
            }, reject);
        }).then(function () {
            return _this._client.platform().commitToTeamServer(_this, branchName, baseRevision);
        });
    };
    return OnlineWorkingCopy;
})();
exports.OnlineWorkingCopy = OnlineWorkingCopy;
/**
 * Team Server Revision
 */
var Revision = (function () {
    // TODO: branch should be optional, in which case mainline is used
    function Revision(num, branch) {
        this._num = num;
        this._branch = branch;
    }
    Revision.prototype.num = function () {
        return this._num;
    };
    Revision.prototype.branch = function () {
        return this._branch;
    };
    Revision.prototype.createWorkingCopy = function () {
        return this._branch.project().createWorkingCopy(this);
    };
    /**
         * TODO: Implementation
         */
    Revision.prototype.deploy = function (onSuccess, onError) {
        var _this = this;
        return when.promise(function (resolve, reject) {
            console.log('Deploying %s@%d of %s:%s...', _this._branch.name(), _this._num, _this._branch.project().name(), _this._branch.project().id());
            var deploymentInfo = null;
            console.log('Deployment of %s@%d of %s:%s successful.', _this._branch.name(), _this._num, _this._branch.project().name(), _this._branch.project().id());
            resolve(deploymentInfo);
        });
    };
    return Revision;
})();
exports.Revision = Revision;
/**
 * Team Server branch line
 */
var Branch = (function () {
    function Branch(project, name) {
        this._project = project;
        this._name = name;
    }
    Branch.prototype.project = function () {
        return this._project;
    };
    Branch.prototype.name = function () {
        return this._name;
    };
    Branch.prototype.retrieveRevisions = function () {
        var _this = this;
        return when.promise(function (resolve, reject) {
            console.log("Retrieving revisions for project " + _this._project.name() + " branch " + _this.name + "...");
            // TODO: Retrieve revisions for this branch with the Platform API
            var revisions = null;
            resolve(revisions);
        });
    };
    return Branch;
})();
exports.Branch = Branch;
function rejectWithError(error, reject) {
    var errorType = typeof (error);
    switch (errorType) {
        case 'ParseError':
            reject("Response parsing error: " + error.message + ". Please consult https://mxforum.mendix.com/");
            break;
        case 'EmptyError':
            reject("Empty response error: " + error.message + ". Please consult https://mxforum.mendix.com/");
            break;
        default:
            reject(error.name + ": " + error.message + ". Please consult https://mxforum.mendix.com/");
            break;
    }
}
//# sourceMappingURL=mendix-platform-sdk.js.map