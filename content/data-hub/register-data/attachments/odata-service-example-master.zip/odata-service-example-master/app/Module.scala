import com.google.inject.{AbstractModule, Provides}
import com.zaxxer.hikari.{HikariConfig, HikariDataSource}
import net.codingwell.scalaguice.ScalaModule
import odata.dataproviders.{ODataDataProvider, RedshiftODataDataProvider, RedshiftODataProviderSettings}
import play.api.Configuration
import javax.inject.Singleton

/**
  * This class is a Guice module that tells Guice how to bind several
  * different types. This Guice module is created when the Play
  * application starts.
  *
  * Play will automatically use any class called `Module` that is in
  * the root package. You can create modules in other locations by
  * adding `play.modules.enabled` settings to the `application.conf`
  * configuration file.
  */
class Module extends AbstractModule with ScalaModule {

  override def configure() = {
    super.configure()

    bind[ODataDataProvider].to[RedshiftODataDataProvider]
  }

  @Provides
  @Singleton
  private def provideAthenaODataDataProvider(config: Configuration): RedshiftODataProviderSettings = {
    val connectionString = config.get[String]("odata.data_providers.redshift.connection_string")
    val username         = config.get[String]("odata.data_providers.redshift.username")
    val password         = config.get[String]("odata.data_providers.redshift.password")

    val settings = RedshiftODataProviderSettings(connectionString, username, password)
    settings
  }

  @Provides
  @Singleton
  private def provideHikariDataSource(settings: RedshiftODataProviderSettings): HikariDataSource = {

    classOf[com.amazon.redshift.jdbc42.Driver]

    val hikariConfig = new HikariConfig
    hikariConfig.setJdbcUrl(settings.connectionString)
    hikariConfig.setMaximumPoolSize(20)
    hikariConfig.setUsername(settings.username)
    hikariConfig.setPassword(settings.password)
    hikariConfig.addDataSourceProperty("cachePrepStmts", "true");
    hikariConfig.addDataSourceProperty("prepStmtCacheSize", "250");
    hikariConfig.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
    hikariConfig.addDataSourceProperty("Workgroup", "primary");
    hikariConfig.addDataSourceProperty("MaxQueryExecutionPollingInterval", "1000")

    new HikariDataSource(hikariConfig)
  }
}
